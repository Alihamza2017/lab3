#include <iostream>

using namespace std;

class Addition
        {
        private:
          int x;
          int y;
        public:
          Addition()
          {}
          void getSum(int x,int y)
          {
            int Sum;
            Sum=x+y;
            std::cout << "Sum of two numbers is " <<Sum<< '\n';


          }




};

        int main()
        {
          Addition A;
          int x;
          int y;
          std::cout << "Enter Your first Value" << '\n';
          cin>>x;
          std::cout << "Enter Your 2nd Value" << '\n';
          cin>>y;
          A.getSum(x,y);
          return 0;
        }
