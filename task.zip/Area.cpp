#include <iostream>

using namespace std;

class rectangle
          {
          private:
            int length;
            int width;

          public:
            int getArea(int l,int w)
            {
              int Area;

              Area=l*w;
            std::cout << "Area Of rectangle is " << Area<<'\n';
            return Area;


            }





};
int main() {
  int l,w;
  cout<<"Enter length"<<endl;
  cin>>l;
  cout<<"Enter Width"<<endl;
  cin>>w;
  rectangle r;
  r.getArea(l,w);
  return 0;
}
